# Chinese Chess

Chinese Chess is also called Xiang Qi, it is a famous and interesting game with a long history.

In a university course, we were asked to make a Xiang Qi game in console version.

This small and simple project is written in C#, and it was used Visual Studio 2019 to be programming.

It is not perfect or advanced for sure, but please enjoy it.
